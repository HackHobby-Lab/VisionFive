#VisionFive

import I2C_LCD_driver
from time import *
import psutil
import re
temp = psutil.sensors_temperatures()

lcd = I2C_LCD_driver.lcd()
lcd.lcd_clear()
lcd.backlight(1)
lcd.lcd_display_string("Welcome this is", 0)
sleep(1)
lcd.lcd_clear()
lcd.lcd_display_string("VisionFive v1", 0)
sleep(1.5)
lcd.lcd_clear()
while 1:
    temp = psutil.sensors_temperatures()
    data = str(temp['124a0000.tmon'])
    words = data.split()
    dab = words[1]
    new = float(re.search("\d+\.\d",dab).group())
    print(f"{new} °C")
    lcd.lcd_display_string("Temperature is:", 0)
    lcd.lcd_display_string(str(f"{new} C"),1,4)
    sleep(0.9)
